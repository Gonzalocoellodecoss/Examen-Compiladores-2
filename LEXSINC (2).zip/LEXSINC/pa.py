from parse import Parser

par = Parser()

def cosa(code):
    ci = par.parse_input(code)
    print(ci)
    return ci

