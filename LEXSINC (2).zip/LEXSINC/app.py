import ply.lex as lex
import ply.yacc as yacc
from flask import Flask, render_template, request
from pa import *

app = Flask(__name__)

# Definición de tokens léxicos
tokens = (
    'INCLUDE',
    'SYMBOL',
    'WORD',
    'SEMICOLON',
    'INT',
    'MAIN',
    'OPEN_PAREN',
    'CLOSE_PAREN',
    'OPEN_BRACE',
    'CLOSE_BRACE',
    'OUTPUT',
    'STREAM',
    'RETURN',
    'INTEGER',
    'STRING',  # Agregamos el token STRING
)

# Reglas para tokens
t_INCLUDE = r'\#'
t_SYMBOL = r'[<>]'
t_WORD = r'[a-zA-Z_][a-zA-Z0-9_]*'
t_SEMICOLON = r';'
t_INT = r'int'
t_MAIN = r'main'
t_OPEN_PAREN = r'\('
t_CLOSE_PAREN = r'\)'
t_OPEN_BRACE = r'\{'
t_CLOSE_BRACE = r'\}'
t_OUTPUT = r'cout'
t_STREAM = r'<<'
t_RETURN = r'return'
t_INTEGER = r'\d+'

# Ignorar espacios y tabulaciones
t_ignore = ' \t'

# Regla para manejar saltos de línea

# Regla para manejar cadenas de texto (entre comillas dobles)
def t_STRING(t):
    r'\"[^\"]*\"'
    t.value = t.value[1:-1]  # Eliminamos las comillas
    return t

def t_newline(t):
    r'\n+'
    t.lexer.lineno += len(t.value)

# Manejo de errores léxicos
def t_error(t):
    print(f"Carácter ilegal '{t.value[0]}' en la línea {t.lexer.lineno}")
    t.lexer.skip(1)

# Construcción del analizador léxico
lexer = lex.lex()

# Reglas sintácticas
def p_program(p):
    '''program : INCLUDE WORD SYMBOL WORD SYMBOL WORD SEMICOLON INT MAIN OPEN_PAREN CLOSE_PAREN OPEN_BRACE OUTPUT STREAM STRING SEMICOLON RETURN INTEGER SEMICOLON CLOSE_BRACE'''
    print("Análisis sintáctico exitoso. El código es válido.")
    return p

def p_error(p):
  # Guardamos el error para mostrarlo en la salida
  global error_sintactico
  if p:
    error_sintactico = f"Error sintáctico en la línea {p.lineno}"
  else:
    error_sintactico = "Error sintáctico general."
  return None

# Variable para almacenar el error sintáctico
error_sintactico = None 

# def p_error(p):
#     return None

# def p_error(p):
#     print(f"Error de sintaxis en la línea {p.lineno}")

# Construcción del analizador sintáctico
parser = yacc.yacc()

# Ejemplo de código
codigo = '''
#include <iostream>
using namespace std;
int main()
{
    cout <<"Hello, World!";
    return 0;
}
'''

# Analizar el código
# lexer = lex.lex()
# lexer.input(codigo)

# for toke in lexer:
#     linea = toke.lineno
#     estado = "LINEA {:4} TIPO {:4} VALOR {:4} POSICION {:4}".format(str(linea), str(toke.type), str(toke.value), str(toke.lexpos))
#     print(estado)

# Analizador sintáctico
# @app.route('/', methods=['GET', 'POST'])
# def index():
#     if request.method == 'POST':
#         codigo = request.form['codigo']
#         lexer.input(codigo)
#         tokens_output = []
#         for toke in lexer:
#             linea = toke.lineno
#             estado = "LINEA {:4} TIPO {:4} VALOR {:4} POSICION {:4}".format(str(linea), str(toke.type), str(toke.value), str(toke.lexpos))
#             tokens_output.append(estado)
#         return render_template('index.html', tokens_output=tokens_output, codigo=codigo)
#     return render_template('index.html', tokens_output=None, codigo=None)

#---------------------------------------------------------------------------------------------------------------------------------------------------------
# @app.route('/', methods=['GET', 'POST'])
# def index():
#     if request.method == 'POST':
#         codigo = request.form['codigo']
#         lexer.input(codigo)
#         tokens_output = []
#         for toke in lexer:
#             linea = toke.lineno
#             estado = "LINEA {:4} TIPO {:4} VALOR {:4} POSICION {:4}".format(str(linea), str(toke.type), str(toke.value), str(toke.lexpos))
#             tokens_output.append(estado)
#         if not tokens_output:
#             return render_template('index.html', tokens_output=["El código no tiene ningún error sintáctico."], codigo=codigo)
#         return render_template('index.html', tokens_output=tokens_output, codigo=codigo)
#     return render_template('index.html', tokens_output=None, codigo=None)

#-------------------------------------------------------------------------------------------------------------------------------------------------
# @app.route('/', methods=['GET', 'POST'])
# def index():
#     if request.method == 'POST':
#         codigo = request.form['codigo']
#         lexer.input(codigo)
#         tokens_output = []
#         for toke in lexer:
#             linea = toke.lineno
#             estado = "LINEA {:4} TIPO {:4} VALOR {:4} POSICION {:4}".format(str(linea), str(toke.type), str(toke.value), str(toke.lexpos))
#             tokens_output.append(estado)
#         if not tokens_output:
#             parser_result = parser.parse(codigo)
#             if parser_result:
#                 return render_template('index.html', tokens_output=["El código no tiene ningún error sintáctico."], codigo=codigo)
#             else:
#                 return render_template('index.html', tokens_output=["El código tiene errores sintácticos."], codigo=codigo)
#         return render_template('index.html', tokens_output=tokens_output, codigo=codigo)
#     return render_template('index.html', tokens_output=None, codigo=None)

#----------------------------------------------------------------------------------------------------------------------------------------------
@app.route('/', methods=['GET', 'POST'])
def index():

  if request.method == 'POST':
    codigo = request.form['codigo']
    lexer.input(codigo)
    tokens_output = []
    pav = cosa(codigo)
    print(pav)
    for toke in lexer:
      linea = toke.lineno
      estado = "LINEA {:4} TIPO {:4} VALOR {:4} POSICION {:4}".format(str(linea), str(toke.type), str(toke.value), str(toke.lexpos))
      tokens_output.append(estado)

    global error_sintactico  # Accedemos a la variable global
    if not tokens_output:
      parser_result = parser.parse(codigo)
      if parser_result:
        return render_template('index.html', tokens_output=["El código no tiene ningún error sintáctico."], codigo=codigo)
      else:
        # Mostramos el error sintáctico
        return render_template('index.html', tokens_output=[error_sintactico], codigo=codigo, pav = pav)
    return render_template('index.html', tokens_output=tokens_output, codigo=codigo)
  
  return render_template('index.html', tokens_output=None, codigo=None)


if __name__ == '__main__':
    app.run(debug=True)