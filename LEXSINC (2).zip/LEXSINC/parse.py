import ply.yacc as yacc
from app import tokens

class Parser:
    def __init__(self):
        # Crear una instancia del analizador léxico
        self.tokens = tokens
        self.parser = yacc.yacc(module=self)

    # Definir las reglas de la gramática
    def p_program(self, p):
        '''program : inicio'''
        p[0] = p[1]

    def p_inicio(self, p):
        '''inicio : INCLUDE WORD SYMBOL WORD SYMBOL mas'''
        p[0] = (p[1], p[2], p[3], p[4], p[5], p[6])

    #mas codigo
    def p_mas(self, p):
        '''mas : code
                | code mas'''
        if len(p) == 2:
            p[0] = p[1]
        else:
            p[0] = (p[1], p[2]) 

    def p_segundo(self, p):
        '''code : WORD WORD WORD SEMICOLON mas'''
        p[0] = (p[1], p[2], p[3], p[4], p[5])

    def p_tercero(self, p):
        '''code : WORD WORD OPEN_PAREN CLOSE_PAREN OPEN_BRACE pp WORD INTEGER SEMICOLON CLOSE_BRACE'''
        p[0] = (p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[10])

    def p_pp(self, p):
        '''pp : pps'''
        p[0] = p[1]

    def p_imp(self, p):
        '''pps : WORD SYMBOL SYMBOL STRING SEMICOLON'''
        p[0] = (p[1], p[2], p[3], p[4], p[5])
    """




            #mas codigo
    def p_args(self, p):
        '''args : cd
                | cd args'''
        if len(p) == 2:
            p[0] = p[1]
        else:
            p[0] = (p[1], p[2])

    def p_argumento(self, p):
        '''cd : DATA_TYPE LBRACKET RBRACKET RESERVED'''
        p[0] = (p[1], p[2], p[3], p[4])

    """
          
    #Gramatica para determinar un vacio
    def p_empty(self, p):
        '''empty :'''
        pass
        
    def p_error(self, p):
        if p:
            raise SyntaxError("Error sintactico de tipo {} en el valor {}, se espera otro valor".format(str(p.type), str(p.value)))
        else:
            raise SyntaxError("Error sintactico, el bloque principal tiene error, asegurate que tenga la estructura melk main(parametros){codigo}")

    # Construir el parser
    start = 'program'
    # Función para analizar una entrada
    def parse_input(self, input_string):
        try:
            return self.parser.parse(input_string)
        except SyntaxError as e:
            return e
        

va = '''#include <iostream>
using namespace std;
int main()
{
    cout <<"Hello, World!";
    return 0;
}
'''